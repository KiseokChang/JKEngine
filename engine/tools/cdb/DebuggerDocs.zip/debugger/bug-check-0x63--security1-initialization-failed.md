---
title: Bug Check 0x63 SECURITY1_INITIALIZATION_FAILED
description: The SECURITY1_INITIALIZATION_FAILED bug check has a value of 0x00000063.This bug check appears very infrequently.
keywords: ["Bug Check 0x63 SECURITY1_INITIALIZATION_FAILED", "SECURITY1_INITIALIZATION_FAILED"]
ms.date: 05/23/2017
topic_type:
- apiref
ms.topic: reference
api_name:
- SECURITY1_INITIALIZATION_FAILED
api_type:
- NA
---

# Bug Check 0x63: SECURITY1\_INITIALIZATION\_FAILED


The SECURITY1\_INITIALIZATION\_FAILED bug check has a value of 0x00000063.

This bug check appears very infrequently.

> [!IMPORTANT]
> This article is for programmers. If you're a customer who has received a blue screen error code while using your computer, see [Troubleshoot blue screen errors](https://www.windows.com/stopcode).


 

 




