---
title: Bug Check 0x1B PFN_SHARE_COUNT
description: The PFN_SHARE_COUNT bug check has a value of 0x0000001B. It indicates that a memory management page frame number (PFN) database element has a corrupted share count. 
keywords: ["Bug Check 0x1B PFN_SHARE_COUNT", "PFN_SHARE_COUNT"]
ms.date: 08/22/2024
topic_type:
- apiref
ms.topic: reference
api_name:
- PFN_SHARE_COUNT
api_type:
- NA
---

# Bug Check 0x1B: PFN\_SHARE\_COUNT


The PFN\_SHARE\_COUNT bug check has a value of 0x0000001B.

This bug check code is no longer used within the Windows operating system.

> [!IMPORTANT]
> This article is for programmers. If you're a customer who has received a blue screen error code while using your computer, see [Troubleshoot blue screen errors](https://www.windows.com/stopcode).


## See also

[Bug Check Code Reference](bug-check-code-reference2.md) 

